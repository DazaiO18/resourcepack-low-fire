package com.example.osTickets.commands;

import com.example.osTickets.TicketManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PayCommand implements CommandExecutor {
    private final TicketManager ticketManager;

    public PayCommand(TicketManager ticketManager) {
        this.ticketManager = ticketManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cТільки гравці можуть використовувати цю команду.");
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage("§fВикористання: §6/tpay <гравець> <кількість>");
            return true;
        }

        Player senderPlayer = (Player) sender;
        Player targetPlayer = Bukkit.getPlayer(args[0]);

        if (targetPlayer == null || !targetPlayer.isOnline()) {
            sender.sendMessage("§cГравець не знайдений або офлайн.");
            return true;
        }

        if (targetPlayer.equals(senderPlayer)) {
            sender.sendMessage("§cВи не можете передати §f₮ самому собі.");
            return true;
        }

        try {
            int amount = Integer.parseInt(args[1]);
            if (amount <= 0) {
                sender.sendMessage("§cСума повинна бути більше 0.");
                return true;
            }

            if (ticketManager.getTickets(senderPlayer) < amount) {
                sender.sendMessage("§cУ вас недостатньо §f₮.");
                return true;
            }

            ticketManager.removeTickets(senderPlayer, amount);
            ticketManager.addTickets(targetPlayer, amount);

            sender.sendMessage("§fВи передали §6" + amount + "§a §f₮ §fгравцю §6" + targetPlayer.getName());
            targetPlayer.sendMessage("§fВи отримали §6" + amount + "§a §f₮ §fвід §6" + senderPlayer.getName());
        } catch (NumberFormatException e) {
            sender.sendMessage("§cНевірна кількість. Введіть число.");
        }

        return true;
    }
}

package com.example.osTickets;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

public class PlaceholderHook extends PlaceholderExpansion {
    private final OsTickets plugin;

    public PlaceholderHook(OsTickets plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean canRegister() {
        return true;
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String getIdentifier() {
        return "ostickets";
    }

    @Override
    public String getAuthor() {
        return "osamu";
    }

    @Override
    public String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public String onRequest(OfflinePlayer player, String identifier) {
        if (player == null) {
            return null;
        }

        TicketManager ticketManager = plugin.getTicketManager();

        if (identifier.equalsIgnoreCase("balance")) {
            Player onlinePlayer = player.getPlayer(); // Отримує онлайн-гравця
            if (onlinePlayer == null) return "0"; // Якщо офлайн, повертаємо "0"
            return String.valueOf(ticketManager.getTickets(onlinePlayer));
        }

        return null;
    }
}

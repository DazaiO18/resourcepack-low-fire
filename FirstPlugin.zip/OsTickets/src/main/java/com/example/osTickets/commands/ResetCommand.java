package com.example.osTickets.commands;

import com.example.osTickets.TicketManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import java.util.UUID;

public class ResetCommand implements CommandExecutor {

    private final TicketManager ticketManager;

    public ResetCommand(TicketManager ticketManager) {
        this.ticketManager = ticketManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("ostickets.admin")) {
            sender.sendMessage(ChatColor.RED + "У вас немає дозволу на цю команду.");
            return true;
        }

        if (args.length != 1) {
            sender.sendMessage("§fВикористання: §6/treset <гравець>");
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if (target == null || target.getName() == null) {
            sender.sendMessage(ChatColor.RED + "Гравця не знайдено.");
            return true;
        }

        UUID uuid = target.getUniqueId();
        ticketManager.setTickets(uuid, 0);

        sender.sendMessage("§aБаланс §f₮ гравця §6" + target.getName() + "§a було скинуто.");
        return true;
    }
}

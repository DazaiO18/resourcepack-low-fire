package com.example.osTickets;

import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class TicketAPI {
    private static OsTickets plugin;

    public static void init(OsTickets instance) {
        plugin = instance;
    }

    public static int getBalance(Player player) {
        if (plugin == null) {
            throw new IllegalStateException("TicketAPI не ініціалізований!");
        }
        if (player == null) {
            return 0; // Запобігає NullPointerException
        }
        return plugin.getConfig().getInt("tickets." + player.getName(), 0);
    }

    public static void setBalance(Player player, int amount) {
        if (plugin == null) {
            throw new IllegalStateException("TicketAPI не ініціалізований!");
        }
        if (player == null) {
            return; // Безпечна перевірка
        }
        plugin.getConfig().set("tickets." + player.getName(), amount);
        plugin.saveConfig();
    }

    public static boolean addTickets(Player player, int amount) {
        if (plugin == null) {
            throw new IllegalStateException("TicketAPI не ініціалізований!");
        }
        if (player == null || amount < 1) {
            return false;
        }
        int newBalance = getBalance(player) + amount;
        setBalance(player, newBalance);
        return true;
    }

    public static boolean removeTickets(Player player, int amount) {
        if (plugin == null) {
            throw new IllegalStateException("TicketAPI не ініціалізований!");
        }
        if (player == null || amount < 1) {
            return false;
        }
        int balance = getBalance(player);
        if (balance < amount) {
            return false;
        }
        setBalance(player, balance - amount);
        return true;
    }
}

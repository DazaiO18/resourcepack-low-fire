package com.example.osTickets.commands;

import com.example.osTickets.TicketManager;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import java.util.*;

public class BaltopCommand implements CommandExecutor {
    private final TicketManager ticketManager;

    public BaltopCommand(TicketManager ticketManager) {
        this.ticketManager = ticketManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        HashMap<UUID, Integer> balances = ticketManager.getAllBalances();
        List<Map.Entry<UUID, Integer>> sortedList = new ArrayList<>(balances.entrySet());

        sortedList.sort((a, b) -> b.getValue().compareTo(a.getValue())); // Сортування від більшого до меншого

        sender.sendMessage("           §fТоп §f₮ §6§lБагачів        ");
        int rank = 1;
        for (Map.Entry<UUID, Integer> entry : sortedList) {
            OfflinePlayer player = Bukkit.getOfflinePlayer(entry.getKey());
            sender.sendMessage("§e" + rank + ". §c" + player.getName() + " §7- §6" + entry.getValue() + " §f₮");
            if (++rank > 10) break;
        }
        return true;
    }
}

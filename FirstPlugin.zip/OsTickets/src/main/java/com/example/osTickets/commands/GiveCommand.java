package com.example.osTickets.commands;

import com.example.osTickets.TicketManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class GiveCommand implements CommandExecutor {
    private final TicketManager ticketManager;

    public GiveCommand(TicketManager ticketManager) {
        this.ticketManager = ticketManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("ostickets.admin")) {
            sender.sendMessage("§cУ вас немає прав використовувати цю команду!");
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage("§fВикористання: §6/tgive <гравець> <кількість>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            sender.sendMessage("§cГравець не знайдений!");
            return true;
        }

        try {
            int amount = Integer.parseInt(args[1]);
            if (amount <= 0) {
                sender.sendMessage("§cКількість §f₮ §сповинна бути більше §f0!");
                return true;
            }

            ticketManager.addTickets(target, amount);
            sender.sendMessage("§aВи видали " + amount + " §f₮ гравцю " + target.getName());
            target.sendMessage("§aВи отримали " + amount + " §f₮!");
        } catch (NumberFormatException e) {
            sender.sendMessage("§cНевірна кількість!");
        }

        return true;
    }
}

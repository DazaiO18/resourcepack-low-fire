package com.example.osTickets.commands;

import com.example.osTickets.TicketManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TicketCommand implements CommandExecutor {

    private final TicketManager ticketManager;

    public TicketCommand(TicketManager ticketManager) {
        this.ticketManager = ticketManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cКоманду можуть виконувати лише гравці!");
            return true;
        }

        sender.sendMessage("§c           §f§lОсTickets §6§lКоманди §c         ");
        sender.sendMessage("§6/tbal §f- Переглянути баланс");
        sender.sendMessage("§6/tpay <гравець> <сума> §f- Передати Тікети");
        sender.sendMessage("§6/tbaltop §f- Топ гравців за балансом");
        sender.sendMessage("§6/ttake §f- Відчислити баланс у гравця");
        sender.sendMessage("§6/tgive §f- Видати баланс гравцю");
        sender.sendMessage("§6/treset §f- Стерти баланс гравцю");
        sender.sendMessage("§c                               ");

        return true;
    }
}

package com.example.osTickets;

import com.example.osTickets.commands.*;
import org.bukkit.ChatColor;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class OsTickets extends JavaPlugin {

    private static OsTickets instance;
    private TicketManager ticketManager;
    private Player player;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new PlaceholderHook(this).register();
            getLogger().info("PlaceholderAPI підключено!");
        }

        ticketManager = new TicketManager(this);

        registerCommand("ticket", new TicketCommand(ticketManager));
        registerCommand("tbal", new BalanceCommand(ticketManager));
        registerCommand("tbaltop", new BaltopCommand(ticketManager));
        registerCommand("tpay", new PayCommand(ticketManager));
        getCommand("tgive").setExecutor(new GiveCommand(ticketManager));
        getCommand("ttake").setExecutor(new TakeCommand(ticketManager));
        getCommand("treset").setExecutor(new ResetCommand(ticketManager));

        getLogger().info("OsTickets успішно активовано!");
    }

    @Override
    public void onDisable() {
        getLogger().info("OsTickets вимкнено.");
    }

    private void registerCommand(String name, Object executor) {
        PluginCommand command = getCommand(name);
        if (command != null) {
            command.setExecutor((org.bukkit.command.CommandExecutor) executor);
        } else {
            getLogger().warning("Команда '" + name + "' не знайдена у plugin.yml!");
        }
    }

    public static OsTickets getInstance() {
        return instance;
    }

    public TicketManager getTicketManager() {
        return ticketManager;
    }
    
}

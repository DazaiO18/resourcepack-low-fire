package com.example.osTickets.commands;

import com.example.osTickets.TicketManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BalanceCommand implements CommandExecutor {
    private final TicketManager ticketManager;

    public BalanceCommand(TicketManager ticketManager) {
        this.ticketManager = ticketManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Тільки гравці можуть використовувати цю команду.");
            return true;
        }

        if (args.length == 0) {
            // Відображаємо баланс самого гравця
            int balance = ticketManager.getBalance(player);
            player.sendMessage(ChatColor.GREEN + "Ваш баланс §f₮: " + ChatColor.YELLOW + balance);
            return true;
        }

        if (args.length == 1) {
            if (!player.hasPermission("ostickets.view.other")) {
                player.sendMessage(ChatColor.RED + "У вас немає прав переглядати баланс інших гравців!");
                return true;
            }

            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                player.sendMessage(ChatColor.RED + "Гравець " + args[0] + " не знайдений або офлайн.");
                return true;
            }

            int targetBalance = ticketManager.getBalance(target);
            player.sendMessage(ChatColor.GREEN + "Баланс гравця " + ChatColor.YELLOW + target.getName() + ChatColor.GREEN + ": " + ChatColor.YELLOW + targetBalance);
            return true;
        }

        player.sendMessage("§fВикористання: §6/tbal [гравець]");
        return true;
    }
}

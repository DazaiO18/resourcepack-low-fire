package com.example.osTickets;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.UUID;

public class TicketManager {
    private final OsTickets plugin;
    private final HashMap<UUID, Integer> ticketBalances = new HashMap<>();

    public TicketManager(OsTickets plugin) {
        this.plugin = plugin;
        loadBalances();
    }

    public int getTickets(Player player) {
        return ticketBalances.getOrDefault(player.getUniqueId(), 0);
    }

    public void setTickets(UUID uuid, int amount) {
        ticketBalances.put(uuid, Math.max(0, amount));
        saveBalances();
    }

    public void setTickets(Player player, int amount) {
        ticketBalances.put(player.getUniqueId(), Math.max(0, amount)); // Захист від від'ємного значення
        saveBalances();
    }

    public void addTickets(Player player, int amount) {
        setTickets(player, getTickets(player) + amount);
    }

    public void removeTickets(Player player, int amount) {
        setTickets(player, Math.max(0, getTickets(player) - amount));
    }

    private void loadBalances() {
        FileConfiguration config = plugin.getConfig();
        if (!config.contains("balances")) return; // Захист від NPE

        for (String key : config.getConfigurationSection("balances").getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                int balance = config.getInt("balances." + key);
                ticketBalances.put(uuid, Math.max(0, balance)); // Захист від від'ємних значень
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Помилка в UUID у balances: " + key);
            }
        }
    }

    private void saveBalances() {
        FileConfiguration config = plugin.getConfig();
        for (UUID uuid : ticketBalances.keySet()) {
            config.set("balances." + uuid.toString(), ticketBalances.get(uuid));
        }
        plugin.saveConfig();
    }

    public HashMap<UUID, Integer> getAllBalances() {
        return new HashMap<>(ticketBalances);
    }

    public int getBalance(Player player) {
        return getTickets(player);
    }
}
